# Drift Checklist V3

This checklist tracks repository-wide drift against the current retrieval-first and QuestionAnalysis v3 baseline.

Review method: lock the target from docs first, then inspect one file at a time.

Source-of-truth documents:
- `docs/README.md`
- `docs/CONTRACT.md`
- `docs/RUNBOOK.md`
- `docs/GOLDEN_TESTS.md`

Core baseline:
- `ids_map` contains resolved identifiers only.
- `candidate_keys.project_key` stores unresolved exact project keys.
- `project_key_policy=ambiguous_or` means exact OR exact discovery, not free-text fallback.
- `join_key_mode=deferred` is a valid runtime strategy.
- `lookup` / `join` with `reason=no_reranked` are `normal_no_result`.
- `search` with `reason=no_reranked` remains `strict_search`.
- `IntentPayloadV3 = transport version + semantic version dual promotion`.

Status labels:
- `aligned`: code/docs/tests match the baseline
- `partial`: direction is correct but cleanup or enforcement remains
- `drift`: baseline mismatch still exists

## 1. Planner / Contract / Query Understanding

| File | Status | Type | Issue | Action |
|---|---|---|---|---|
| `apps/core/query_intent.py` | aligned | v3 / utf8 | cheap precheck boundary, unresolved exact-key handling, and UTF-8 text are aligned with the planner-first baseline | none |
| `apps/core/planner_contract.py` | aligned | v3 | resolved `ids_map` contract and planner XOR rules follow v3 baseline | none |
| `apps/api/contracts/runtime_contracts.py` | aligned | v3 / utf8 | explicit and ambiguous project-key labels, slot labels, and hygiene validation now match the v3 baseline | none |
| `apps/api/services/request_facade.py` | aligned | v3 | request assembly propagates planner-first execution metadata | none |
| `apps/api/services/planner_service.py` | aligned | architecture / v3 | planner merge preserves v3 fields and extended query-graph metadata | none |
| `apps/api/services/planner_runtime.py` | aligned | v3 | post-sanitize re-gate and downgrade behavior match current baseline | none |
| `apps/core/pipeline_steps.py` | aligned | architecture | query-plan metadata for aggregation, series, reverse trace, pattern, and bundle is present | none |
| `apps/core/schemas.py` | aligned | v3 / docs | transport contract and remaining compatibility comments are aligned with the current baseline | none |

## 2. Runtime / Orchestration / Filters

| File | Status | Type | Issue | Action |
|---|---|---|---|---|
| `apps/core/rag_runtime_prelude.py` | aligned | v3 | strategy summary exposes v3 and query-graph observability fields | none |
| `apps/core/rag_pipeline.py` | aligned | v3 | `IntentPayloadV3` gate is active for payload-bearing paths; legacy `None` path is the only intentional exception | none |
| `apps/core/filters.py` | aligned | architecture / utf8 | deferred and ambiguous filtering remain intact, and resolved-only validation comments are now readable | none |
| `apps/core/rag_base_orchestration.py` | aligned | architecture | lookup/search orchestration respects current no-result baseline | none |
| `apps/core/rag_join_runtime.py` | aligned | architecture / utf8 | deferred join runtime and branch-merge helpers are readable and still follow the current baseline | none |
| `apps/core/rag_join_orchestration.py` | aligned | architecture / v3 | deferred resolution and dual-branch handling are implemented | none |
| `apps/core/result_contract.py` | aligned | v3 | empty-result policy is split correctly between `normal_no_result` and strict failures | none |
| `apps/core/retrieval.py` | aligned | architecture / utf8 | retrieval module text is UTF-8 readable and behavior remains aligned with the current baseline | none |
| `apps/api/services/llm_json.py` | aligned | utf8 | JSON extraction helpers are UTF-8 readable and behavior remains unchanged | none |
| `apps/api/services/runtime_helpers.py` | aligned | utf8 | logging and summary helpers are UTF-8 readable and still follow the v3 baseline | none |
| `apps/api/services/workflow_nodes.py` | aligned | architecture / utf8 | workflow node text and canned Korean responses are UTF-8 readable and behavior remains aligned | none |
| `apps/api/services/workflow_builder.py` | aligned | architecture / utf8 | workflow graph assembly is UTF-8 readable and still matches the retrieval-first flow | none |
| `apps/api/services/retrieval_workflow.py` | aligned | architecture / utf8 | retrieval workflow nodes are UTF-8 readable and preserve the current planner-first routing behavior | none |
| `apps/api/services/answer_generation.py` | aligned | architecture / utf8 | answer-generation context and streaming helpers are readable and preserve the raw-to-canonical boundary | none |
| `apps/api/services/answer_merge.py` | aligned | architecture / utf8 | answer merge policy is readable and remains behaviorally unchanged | none |

## 3. Extended Runtime Outputs

| File | Status | Type | Issue | Action |
|---|---|---|---|---|
| `apps/core/rag_runtime_safety.py` | aligned | architecture / utf8 | aggregation, series, pattern, and bundle helpers are readable and preserve the current runtime behavior | none |
| `apps/core/rag_dispatch_runtime.py` | aligned | architecture | dispatch covers extended runtime branches | none |
| `apps/api/services/rag_result_assembly.py` | aligned | architecture / utf8 | output assembly docs are readable and extended payload handling remains unchanged | none |
| `apps/api/services/rag_retriever.py` | aligned | architecture / v3 | retriever transports v3 metadata and extended evidence payloads | none |
| `apps/api/services/context_renderer.py` | aligned | architecture / utf8 | renderer helper docs are readable and extended source rendering remains unchanged | none |
| `apps/api/app_factory.py` | aligned | architecture / utf8 | summary/debug assembly remains readable and no mojibake cleanup is pending in this file | none |

## 4. Prompts / Docs / Golden / Integrity

| File | Status | Type | Issue | Action |
|---|---|---|---|---|
| `prompts/planner_stage2_v1.md` | aligned | architecture / utf8 | planner prompt carries v3 and extended-runtime vocabulary | none |
| `docs/README.md` | aligned | docs | onboarding, source-of-truth mapping, and current baseline are readable and current | none |
| `docs/CONTRACT.md` | aligned | docs | retrieval/runtime/v3 contract is readable and matches the current baseline | none |
| `docs/RUNBOOK.md` | aligned | docs | triage, observability, and no-result policy are readable and current | none |
| `docs/GOLDEN_TESTS.md` | aligned | docs | golden queries and invariants are readable and current | none |
| `tests/test_doc_guides.py` | aligned | tests | checklist-aware doc validation is in place for the current v3 baseline | none |
| `tests/test_text_integrity.py` | aligned | tests | integrity checks now track the checklist, current AGENTS vocabulary, and v3 document tokens | none |

## 4A. Additional Repository Coverage

| File | Status | Type | Issue | Action |
|---|---|---|---|---|
| `.agents/skills/ntis-rag-context-refine/SKILL.md` | aligned | reference docs | reference docs are UTF-8 readable and remain consistent with the canonical NTIS semantics | none |
| `.agents/skills/ntis-rag-context-refine/references/canonical-schema.md` | aligned | reference docs | reference docs are UTF-8 readable and remain consistent with the canonical NTIS semantics | none |
| `.agents/skills/ntis-rag-context-refine/references/invariants.md` | aligned | reference docs | reference docs are UTF-8 readable and remain consistent with the canonical NTIS semantics | none |
| `.agents/skills/ntis-rag-context-refine/references/raw-to-context-examples.md` | aligned | reference docs | reference docs are UTF-8 readable and remain consistent with the canonical NTIS semantics | none |
| `.agents/skills/ntis-rag-context-refine/references/source-data-semantics.md` | aligned | reference docs | reference docs are UTF-8 readable and remain consistent with the canonical NTIS semantics | none |
| `AGENTS.md` | aligned | repo metadata | repository metadata is readable and does not conflict with the current baseline | none |
| `apps/__init__.py` | aligned | repo metadata | repository metadata is readable and does not conflict with the current baseline | none |
| `apps/api/__init__.py` | aligned | repo metadata | repository metadata is readable and does not conflict with the current baseline | none |
| `apps/api/contracts/__init__.py` | aligned | repo metadata | repository metadata is readable and does not conflict with the current baseline | none |
| `apps/api/rag_mapper/__init__.py` | aligned | repo metadata | repository metadata is readable and does not conflict with the current baseline | none |
| `apps/api/rag_mapper/domains/__init__.py` | aligned | repo metadata | repository metadata is readable and does not conflict with the current baseline | none |
| `apps/api/services/__init__.py` | aligned | repo metadata | repository metadata is readable and does not conflict with the current baseline | none |
| `apps/core/__init__.py` | aligned | repo metadata | repository metadata is readable and does not conflict with the current baseline | none |
| `pytest.ini` | aligned | repo metadata | repository metadata is readable and does not conflict with the current baseline | none |

## 4B. Additional Runtime and Mapper Coverage

| File | Status | Type | Issue | Action |
|---|---|---|---|---|
| `apps/api/contracts/workflow_models.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/api/main.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/api/rag_mapper/domains/compound.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/domains/equipment.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/domains/manual.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/domains/organism_info.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/domains/organism_resource.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/domains/paper.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/domains/patent.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/domains/project.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/domains/qna.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/domains/report.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/domains/researcher.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/domains/software.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/domains/standard.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/domains/tech_summary.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/domains/variety.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/mapping_config.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/rag_mapper.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/rag_mapper/schema_types.py` | aligned | mapper | mapper/schema text is readable and preserves raw-to-canonical semantics | none |
| `apps/api/routes.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/api/runtime.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/api/services/canonical_context.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/api/services/context_build_policy.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/api/services/context_helpers.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/api/services/conversation_store.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/api/services/llm_runtime.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/api/services/query_analysis.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/api/services/rag_postprocess_policy.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/api/services/render_profile.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/anchor_resolution.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/canonical_evidence.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/llm_streaming.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/log_keys.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/metrics.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/openai_compat_llm.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/planner_locking.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/planner_staged.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_collection_retrieval.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_compile_runtime.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_constants.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_dense_runtime_support.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_execution_policy.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_executor_support.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_filter_policy.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_hydration_runtime.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_rank_runtime.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_rerank_support.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_runtime_observability.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_search_policy.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_store.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_strategy_guard.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/rag_types.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/runtime_strategy_policy.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/settings.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/storage.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/triton_client.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |
| `apps/core/triton_llm.py` | aligned | architecture / utf8 | supporting runtime code is readable and consistent with the current retrieval-first and v3 baseline | none |

## 4C. Additional Docs and Prompt Coverage

| File | Status | Type | Issue | Action |
|---|---|---|---|---|
| `docs/ADR/ADR-0001-llm-streaming-reasoning-policy.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |
| `docs/ADR/ADR-0002-strict-contract-default-transition.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |
| `docs/ADR/ADR-0003-stagewise-planner-adoption.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |
| `docs/ARCHITECTURE_RETRIEVAL_FIRST.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |
| `docs/DRIFT_CHECKLIST_V3.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |
| `docs/ENVIRONMENT.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |
| `docs/MAINTENANCE_TASK_MASTER.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |
| `docs/MODE_DECISION_GUIDE.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |
| `docs/NTIS_RAG_Search_Strategy_v1_2.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |
| `docs/PLANNER_PARAMETER_REFERENCE.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |
| `docs/RETRIEVAL_ROBUSTNESS_PLAN.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |
| `docs/SYSTEM_FLOW_RETRIEVAL_FIRST.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |
| `docs/project_key_env_contract.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |
| `prompts/ntis_chatbot.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |
| `prompts/planner_stage1_v1.md` | aligned | docs | supporting docs/prompts are UTF-8 readable and consistent with the current baseline | none |

## 4D. Additional Test Coverage

| File | Status | Type | Issue | Action |
|---|---|---|---|---|
| `tests/test_anchor_resolution.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_answer_generation_context.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_answer_generation_no_result.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_api_routes_runtime.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_app_factory_summary.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_architecture_plan_metadata.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_context_renderer_aggregation.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_context_renderer_pattern.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_context_renderer_series.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_conversation_store.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_filters.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_knowledge_sufficiency_context.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_planner_canonical_runtime.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_planner_contract.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_planner_runtime.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_planner_service.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_planner_stagewise.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_query_intent_aggregation.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_query_intent_series.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_base_orchestration.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_collection_retrieval.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_dense_runtime_support.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_dispatch_runtime.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_execution_policy.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_executor_support.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_filter_policy.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_join_orchestration.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_pipeline_no_promotion.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_rerank_support.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_retriever.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_runtime_observability.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_runtime_prelude.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_runtime_safety.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_runtime_safety_bundle.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_rag_runtime_safety_pattern.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_request_facade_and_context.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_result_contract.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_retrieval_workflow.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_runtime_contracts.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_schemas_target_collections.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_strategy_spec_response.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_workflow_memory_rehydrate.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |
| `tests/test_workflow_models.py` | aligned | tests | test expectations are readable and aligned with the current baseline | none |

## 4E. Eval, Deploy, and Tooling Coverage

| File | Status | Type | Issue | Action |
|---|---|---|---|---|
| `deploy/env/prod.env.example` | aligned | ops / eval | supporting assets are UTF-8 readable and do not conflict with the current baseline | none |
| `deploy/env/staging.env.example` | aligned | ops / eval | supporting assets are UTF-8 readable and do not conflict with the current baseline | none |
| `deploy/helm/values-prod.yaml` | aligned | ops / eval | supporting assets are UTF-8 readable and do not conflict with the current baseline | none |
| `deploy/helm/values-staging.yaml` | aligned | ops / eval | supporting assets are UTF-8 readable and do not conflict with the current baseline | none |
| `eval/README.md` | aligned | ops / eval | supporting assets are UTF-8 readable and do not conflict with the current baseline | none |
| `eval/queries.csv` | aligned | ops / eval | supporting assets are UTF-8 readable and do not conflict with the current baseline | none |
| `eval/queries.json` | aligned | ops / eval | supporting assets are UTF-8 readable and do not conflict with the current baseline | none |
| `eval/run_eval.py` | aligned | ops / eval | supporting assets are UTF-8 readable and do not conflict with the current baseline | none |
| `eval/sample_queries.jsonl` | aligned | ops / eval | supporting assets are UTF-8 readable and do not conflict with the current baseline | none |
| `scripts/run_baseline_checks.ps1` | aligned | ops / eval | supporting assets are UTF-8 readable and do not conflict with the current baseline | none |
| `templates/index.html` | aligned | ops / eval | supporting assets are UTF-8 readable and do not conflict with the current baseline | none |

## 5. Global Checklist

- [x] `pjt_id` and `pjt_no` remain distinct semantics.
- [x] `candidate_keys.project_key` is transport-visible in v3.
- [x] `join_key_mode=deferred` is accepted end-to-end.
- [x] `lookup` / `join` zero-hit behavior uses `normal_no_result`.
- [x] `IntentPayloadV3` is the active payload contract.
- [x] `/query/debug` and `REQ.SUMMARY` expose v3 fields.
- [x] Authoritative docs are fully UTF-8 readable.
- [x] Remaining mojibake in comments/docstrings is removed from core runtime files.
- [x] Integrity tests cover all current control documents and checklist expectations.

## 6. Priority Order

P0:
- 없음

P1:
- Keep checklist and integrity tests synchronized with future code changes

P2:
- Remove remaining legacy aliases/comments where they no longer help compatibility
