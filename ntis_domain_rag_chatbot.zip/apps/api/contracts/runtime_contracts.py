"""Runtime contract helpers kept separate from the main server module.\n\nThese helpers validate env and planner payload semantics in a location that both tests and\nstartup code can import directly.\n"""

from __future__ import annotations

import os
import re
from typing import Any, Callable

PLANNER_STAGE2_IDS_MAP_ALLOWED_KEYS = {
    "pjt_id",
    "pjt_no",
    "doi",
    "issn",
    "eissn",
    "pissn",
    "rst_id",
    "perf_id",
    "paper_id",
    "patent_reg_no",
    "patent_app_no",
    "person_no",
    "biz_no",
    "org_code",
    "org_id",
}


def validate_project_key_env_contract(
    *,
    env: Any = os.environ,
    log_info: Callable[..., None] | None = None,
) -> tuple[str, str]:
    """환경변수로 지정한 project instance/group key 이름이 서로 다른지 검증한다."""
    pjt_id_key = str(env.get("RAG_KEY_PJT_ID", "pjt_id")).strip() or "pjt_id"
    pjt_no_key = str(env.get("RAG_KEY_PJT_NO", "pjt_no")).strip() or "pjt_no"
    if pjt_id_key == pjt_no_key:
        raise RuntimeError(
            "RAG_KEY_PJT_ID and RAG_KEY_PJT_NO must differ "
            f"(got {pjt_id_key!r})"
        )
    if log_info is not None:
        log_info(
            "[startup][key-mapping] RAG_KEY_PJT_ID=%s, RAG_KEY_PJT_NO=%s",
            pjt_id_key,
            pjt_no_key,
        )
    return pjt_id_key, pjt_no_key


def sanitize_ids_map_semantics(
    ids_map: dict[str, list[str]],
    *,
    allowed_keys: set[str] | None = None,
) -> tuple[dict[str, list[str]], list[dict[str, Any]]]:
    """planner ids_map에서 허용된 key와 값 형식만 남기고 나머지는 invalid 목록으로 분리한다.

    pjt_id와 pjt_no를 다른 규칙으로 검사해 두 식별자 의미가 섞이지 않게 한다.
    """
    cleaned: dict[str, list[str]] = {}
    invalid: list[dict[str, Any]] = []
    allowed = allowed_keys or PLANNER_STAGE2_IDS_MAP_ALLOWED_KEYS
    patterns = {
        "pjt_id": re.compile(r"^\d{8,12}$"),
        "doi": re.compile(r"^10\.\d{4,9}/[-._;()/:A-Z0-9]+$", re.I),
        "issn": re.compile(r"^\d{4}-\d{3}[\dXx]$"),
        "eissn": re.compile(r"^\d{4}-\d{3}[\dXx]$"),
        "pissn": re.compile(r"^\d{4}-\d{3}[\dXx]$"),
        "patent_reg_no": re.compile(r"^[A-Za-z0-9\-]{6,}$"),
        "patent_app_no": re.compile(r"^[A-Za-z0-9\-]{6,}$"),
        "rst_id": re.compile(r"^(?:RPT|RST)-?[A-Za-z0-9\-]{2,}$", re.I),
        "perf_id": re.compile(r"^(?:PERF|PFM)-?[A-Za-z0-9\-]{2,}$", re.I),
        "paper_id": re.compile(r"^(?:PAP|PAPER)-?[A-Za-z0-9\-]{2,}$", re.I),
        "person_no": re.compile(r"^\d{6,12}$"),
        "biz_no": re.compile(r"^\d{3}-?\d{2}-?\d{5}$"),
        "org_code": re.compile(r"^[A-Z][A-Z0-9_\-]{2,15}$"),
        "org_id": re.compile(r"^[A-Za-z][A-Za-z0-9_\-]{2,31}$"),
    }
    hangul_only = re.compile(r"^[0-9\s]+$")
    for key, values in (ids_map or {}).items():
        if key not in allowed:
            for raw in values or []:
                value = str(raw).strip()
                if value:
                    invalid.append({"key": key, "value": value})
            continue
        out: list[str] = []
        for raw in values or []:
            value = str(raw).strip()
            if not value:
                continue
            ok = True
            if key == "pjt_no":
                ok = not bool(hangul_only.match(value))
            elif key in patterns:
                ok = bool(patterns[key].match(value))
            if not ok:
                invalid.append({"key": key, "value": value})
                continue
            out.append(value)
        if out:
            cleaned[key] = out
    return cleaned, invalid


def friendly_strategy_violation_message(
    *,
    error_code: str,
    reason: str,
    question_analysis: Any,
) -> str:
    """전략 위반이나 빈 결과 계약 실패를 사용자 친화적인 한국어 문장으로 바꾼다."""
    mode = str(getattr(question_analysis, "mode", "") or "").strip().upper()
    action = str(getattr(question_analysis, "action", "") or "").strip().lower()
    ids_map = getattr(question_analysis, "ids_map", None) or {}
    has_explicit_id = isinstance(ids_map, dict) and any(bool(v) for v in ids_map.values())

    if error_code == "RAG_EMPTY_RESULT_CONTRACT" and mode == "LOOKUP":
        if action == "detail" or has_explicit_id:
            return "조건에 맞는 조회 결과를 찾지 못했습니다. 식별자나 질의 조건이 정확한지 다시 확인해 주세요."
        if action == "list":
            return "조건에 맞는 목록 결과를 찾지 못했습니다. 기관명, 인명, 연도 같은 조건을 조금 더 넓혀서 다시 시도해 주세요."
    return "요청을 처리할 수 있는 검색 결과를 만들지 못했습니다. 질의를 조금 더 구체적으로 바꾸어 다시 시도해 주세요."


